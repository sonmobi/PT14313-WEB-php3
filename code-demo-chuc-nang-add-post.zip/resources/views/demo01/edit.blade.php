<h1>Trang sửa</h1>
Họ và tên: {{$ten}} <br>
Cách 2:  {!!  $ten    !!} <br>
ID = {{$id}}
