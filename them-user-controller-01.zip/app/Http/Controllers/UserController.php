<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index(){

        return view('user.index');
    }
    public function add(){
        return view('user.add');
    }
}
