<h1>Trang thêm mới</h1>
URL: {{  route('Demo01.add') }}
<br><a href="{{  route('Demo01.add') }}">Link thêm mới</a>
<br>URL edit, iduser = 5
<br> {{ route('Demo01.edit', ['iduser'=>5 ]  ) }}

