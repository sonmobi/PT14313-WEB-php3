<h2>Danh sách tài khoản</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>STT</th>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Fullname</th>
    </tr>
    <tr>
        <td></td> <td></td>
        <td></td> <td></td>
        <td></td>
    </tr>
</table>
